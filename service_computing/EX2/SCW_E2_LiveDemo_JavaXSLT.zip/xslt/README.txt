* Source of sample files: http://www.w3schools.com/xsl/xsl_transformation.asp

* Run the following command: java -jar transform.jar ./files/cdcatalog.xsl ./files/cdcatalog.xml > cdcatalog.html

* It transforms the XML data stored in cdcatalog.xml using the rules defined in cdcatalog.xsl and writes the HTML output to cdcatalog.html
